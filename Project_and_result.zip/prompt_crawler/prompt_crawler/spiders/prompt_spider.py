import scrapy
import csv


class PromptSpiderSpider(scrapy.Spider):
    name = "prompt_spider"
    allowed_domains = ["flowgpt.com"]
    start_urls = ["https://flowgpt.com"]

    prompts = []

    def parse(self, response):
        # ����Ƿ�������ȡ
        if "/user" in response.url:
            self.log(f"Ignoring URL: {response.url} (Blocked by robots.txt)")
            return


        parent_elements = response.css('div.flex.flex-row.flex-wrap.gap-2')
        for parent_element in parent_elements:
            prompts = parent_element.css('span.css-1ny2kle::text').getall()  # ��ȡ��ʾ���ı�
            for prompt in prompts:
                prompt_text = prompt.strip()
                print("prompt:", prompt_text)
        yield {'prompts': prompt_text}  # ��ÿ����ʾ����Ϊ�ֵ���ʽ��item����
